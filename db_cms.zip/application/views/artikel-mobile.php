


<hr>
<div class="media">
  <img src="..." class="mr-3" alt="...">
  <div class="media-body"  style="font-size: 30px;">
    <h1 class="display-4">Media heading</h1>
    <div class="row">
      <div class="col" style="padding-right: 0;">
        <small style="font-size: 30px;"><i class="fa fa-eye"></i> 15</small> <small style="font-size: 30px;"><i class="fa fa-thumbs-up"></i> 15</small style="font-size: 30px;"> <small style="font-size: 30px;"><i class="fa fa-thumbs-down"></i> 0</small> <small style="font-size: 30px;"><i class="fa fa-comments"></i> 15</small> 
      </div>
      <div class="col" style="padding-left:2px;">
        <small style="font-size: 30px;"><i class="fa fa-calendar"></i> 13/04/2000</small> <small style="font-size: 30px;"><i class="fa fa-pencil"></i> Admin</small>
      </div>
    </div>
    <hr>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>

    <hr>
    <div class="row" style="width: 100%" align="center">
      <div class="col">
        <div>Suka</div>
      </div>

      <div class="col">
        <div>Tidak Suka</div>
      </div>

    </div>
    <hr>
    <h1><b>Komentar ... </b></h1>
    <hr>
    <div class="media" style="font-size: 25px;">
      <img src="..." class="mr-3" alt="...">
      <div class="media-body">
        <h1>Nama</h1>
        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
      </div>
    </div>
    <hr>
    <form>
      <div class="form-group">
        <h1><b>Komentar : </b></h1>
        <textarea class="form-control" id="komentar" name="komentar" style="font-size: 30px;"></textarea>
      </div>
      <button style="font-size: 30px;" type="submit" class="btn btn-success">Kirim Komentar</button>
    </form>
    <hr>
  </div>
</div>
<hr>
<div align="center">
  <div style="width: 720px;height: 120px;" class="bg-secondary text-light">
    <h3>Iklan</h3>
  </div>
</div>
<hr>
<h1><b>Artikel Terkait ...</b></h1>
<hr>
<div class="media">
  <img src="..." class="mr-3" alt="...">
  <div class="media-body">
    <h1 class="mt-0">Media heading</h1>
    <hr>
    <p style="font-size: 30px;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    <hr>
    <div class="row">
      <div class="col" style="padding-right: 0;">
        <small style="font-size: 30px;"><i class="fa fa-eye"></i> 15</small> <small style="font-size: 30px;"><i class="fa fa-thumbs-up"></i> 15</small style="font-size: 30px;"> <small style="font-size: 30px;"><i class="fa fa-thumbs-down"></i> 0</small> <small style="font-size: 30px;"><i class="fa fa-comments"></i> 15</small> 
      </div>
      <div class="col" style="padding-left:2px;">
        <small style="font-size: 30px;"><i class="fa fa-calendar"></i> 13/04/2000</small> <small style="font-size: 30px;"><i class="fa fa-pencil"></i> Admin</small>
      </div>
    </div>
  </div>
</div>
<hr>
<div class="media">
  <img src="..." class="mr-3" alt="...">
  <div class="media-body">
    <h1 class="mt-0">Media heading</h1>
    <hr>
    <p style="font-size: 30px;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    <hr>
    <div class="row">
      <div class="col" style="padding-right: 0;">
        <small style="font-size: 30px;"><i class="fa fa-eye"></i> 15</small> <small style="font-size: 30px;"><i class="fa fa-thumbs-up"></i> 15</small style="font-size: 30px;"> <small style="font-size: 30px;"><i class="fa fa-thumbs-down"></i> 0</small> <small style="font-size: 30px;"><i class="fa fa-comments"></i> 15</small> 
      </div>
      <div class="col" style="padding-left:2px;">
        <small style="font-size: 30px;"><i class="fa fa-calendar"></i> 13/04/2000</small> <small style="font-size: 30px;"><i class="fa fa-pencil"></i> Admin</small>
      </div>
    </div>
  </div>
</div>
<hr>
<div class="media">
  <img src="..." class="mr-3" alt="...">
  <div class="media-body">
    <h1 class="mt-0">Media heading</h1>
    <hr>
    <p style="font-size: 30px;">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
    quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
    consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
    cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
    proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
    <hr>
    <div class="row">
      <div class="col" style="padding-right: 0;">
        <small style="font-size: 30px;"><i class="fa fa-eye"></i> 15</small> <small style="font-size: 30px;"><i class="fa fa-thumbs-up"></i> 15</small style="font-size: 30px;"> <small style="font-size: 30px;"><i class="fa fa-thumbs-down"></i> 0</small> <small style="font-size: 30px;"><i class="fa fa-comments"></i> 15</small> 
      </div>
      <div class="col" style="padding-left:2px;">
        <small style="font-size: 30px;"><i class="fa fa-calendar"></i> 13/04/2000</small> <small style="font-size: 30px;"><i class="fa fa-pencil"></i> Admin</small>
      </div>
    </div>
  </div>
</div>
