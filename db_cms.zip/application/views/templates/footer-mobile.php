
<br>
<br>
<div align="center">
  <div style="width: 720px;height: 120px;" class="bg-secondary text-light">
    <h3>Iklan</h3>
  </div>
</div>

</div>




<div style="bottom: 0;position: fixed;width: 100%;padding-top:50px; z-index: 99;" align="center">
	<div class="card bg-dark text-light" style="border-radius: 0;height:150px;font-size: 50px;">
		<div class="row" style="padding: 32px;">
			<div class="col" style="cursor: pointer;">Beranda</div>
			<div class="col" style="cursor: pointer;">Kategori</div>
			<div class="col" style="cursor: pointer;">Tag</div>
			<div class="col" style="cursor: pointer;">Trending</div>
		</div>
	</div>
</div>

</body>
	<script type="text/javascript" src="//<?php echo base_url("assets/js/ajax.js") ?>"></script>
	<script type="text/javascript" src="//<?php echo base_url("assets/js/bootstrap.js") ?>"></script>
	<script type="text/javascript" src="//<?php echo base_url("assets/js/bootstrap.bundle.js") ?>"></script>
	
</html>