
<div class="modal" tabindex="-1" role="dialog" id="prop_modal">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modal-header"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="modal-body">
      </div>
      <div class="modal-footer" id="modal-footer">
      </div>
    </div>
  </div>
</div>

</body>
	<script type="text/javascript" src="//<?php echo base_url("assets/js/ajax.js") ?>"></script>
	<script type="text/javascript" src="//<?php echo base_url("assets/js/bootstrap.js") ?>"></script>
	<script type="text/javascript" src="//<?php echo base_url("assets/js/bootstrap.bundle.js") ?>"></script>
	<script type="text/javascript" src="//cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
</html>