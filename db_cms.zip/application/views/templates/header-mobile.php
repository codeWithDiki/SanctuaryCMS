<!DOCTYPE html>
<html style="height: 100%">
<head>
	<title>NULL</title>
	<link rel="stylesheet" type="text/css" href="//<?php echo base_url("assets/css/bootstrap.css") ?>">
	<link rel="stylesheet" type="text/css" href="//<?php echo base_url("assets/css/bootstrap-grid.css") ?>">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<script type="text/javascript" src="//<?php echo base_url("assets/js/ajax.js") ?>"></script>
	<script type="text/javascript" src="//<?php echo base_url("assets/js/bootstrap.js") ?>"></script>
	<script type="text/javascript" src="//<?php echo base_url("assets/js/bootstrap.bundle.js") ?>"></script>
	<script type="text/javascript" src="//<?php echo base_url("assets/js/ckeditor.js") ?>"></script>
	<style type="text/css">
		.opening-bg {
			background-image: url('//<?php echo base_url("assets/images/code3.jpg") ?>');height:300px;/* Add the blur effect */
  			filter: blur(8px);
  			-webkit-filter: blur(8px);
  			background-position: center;
  			background-repeat: no-repeat;
  			background-size: cover;
		}
	</style>
</head>
<body class="bg-secondary">

	<div class="row bg-dark text-light" style="width: 100%;margin: 0;height: 150px;" align="center">
		<div class="col-md-3 mr-auto" style="justify-content: center;"><h1 style="font-size: 50px;top:50%;display: block;"><i><b>SantuyBlogger.com</b></i></h1></div>
		<div class="col-md-6 ml-auto" align="center" style="justify-content: center; margin-left: 30px;">
			<div class="btn-group" style="top:30%; width: 100%">
				<button class="btn btn-danger" style="font-size: 30px;"><B><i>Subscribe</i></B></button>
			</div>
		</div>	
	</div>

	<div style="margin-bottom:200px;margin-top:0;padding: 2%;box-shadow: 5px 10px 8px #888888;" class="bg-light">